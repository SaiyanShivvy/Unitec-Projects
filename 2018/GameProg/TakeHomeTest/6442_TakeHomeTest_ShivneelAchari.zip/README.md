## Author: Shivneel Achari
## SID: 1463570
## Notes:
 - Made in VS2017
 - SFML is linked automatically using [vcpkg](https://github.com/Microsoft/vcpkg)
 - Since it is automatically linked using vcpkg, there is nothing in the configurations of the projects for additional header and include folders for sfml
 - To install sfml using vcpkg; after installation of vcpkg, run .\vcpkg install sfml or manually link them.
 - Each Project has some notes commented just incase there was issues I couldn't fix due to time constraints and other assignments/finals.

## Note for the lecturer: Thanks for teaching us!