# DSA LAB 3

# Instructions
Contains full VS 2017 Project so it should run by loading the solution into VS 2017.

### Known Issues:
- myQueue->front was nullptr, if you try run both EmptyQueue() and RandomDequeue() functions that issue comes up.
I currently don't understand the cause of the issue, however running the function seperately it works fine. 

## LICENCE
MIT License

##### Author: Shivneel Achari
###### Last Edit: 1st May 2018, 10:45pm