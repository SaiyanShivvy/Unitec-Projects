# Assignment 1
## Infix to Postfix/Prefix

# Instructions
Contains full VS 2017 Project so it should run by loading the solution into VS 2017.

### Known Issues:
None - So far.

## LICENCE
MIT License

##### Author: Shivneel Achari
###### Last Edit: 2st May 2018, 11:28pm